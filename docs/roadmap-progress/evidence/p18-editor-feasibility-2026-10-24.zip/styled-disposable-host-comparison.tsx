// P18 disposable host experiment. Remove after capturing the feasibility receipt.
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Popover, QueryInput, type QueryDocument } from '@omniviewdev/base-ui';
import { CelQueryEditor } from '@omniviewdev/editors';
import { createCelDevelopmentAdapter } from '../../../ui/packages/editors/src/development/cel-language-service';
import '@omniviewdev/editors/styles.css';
import type * as Monaco from 'monaco-editor';

type Candidate = 'lightweight' | 'monaco';
const evidence = {
  source: 'p18-host-comparison-37c896d0-v1',
  events: [] as { kind: string; candidate: string; at: number; detail?: unknown }[],
  editors: {} as Partial<Record<Candidate, Monaco.editor.IStandaloneCodeEditor>>,
  monaco: undefined as typeof Monaco | undefined,
};
Object.assign(window, { __P18: evidence });
function event(kind: string, candidate: string, detail?: unknown) {
  evidence.events.push({ kind, candidate, at: performance.now(), detail });
}

function CandidateSurface({ candidate, started }: { candidate: Candidate; started: number }) {
  const [adapter] = useState(() => createCelDevelopmentAdapter('cloud', 'http://127.0.0.1:16138'));
  const [document, setDocument] = useState<QueryDocument>({ text: 'resource.', version: 1, uri: `p18-${candidate}:///query.cel` });
  const [submissions, setSubmissions] = useState(0);
  const root = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    if (candidate === 'lightweight') event('mounted', candidate, { elapsed: performance.now() - started });
  }, [candidate, started]);
  useEffect(() => () => {
    delete evidence.editors[candidate];
    void adapter.dispose().then(() => event('adapter-disposed', candidate));
    event('unmounted', candidate);
  }, [adapter, candidate]);
  const common = {
    document, contextKey: `p18-cloud-${candidate}`,
    onChange: (text: string) => setDocument(previous => ({ ...previous, text, version: previous.version + 1 })),
    request: adapter.languageService, debounceMs: 250, maxSuggestions: 50,
    label: `${candidate} cloud query`,
    onSubmit: () => { event('submit', candidate, document.text); setSubmissions(value => value + 1); },
  };
  return <div ref={root} data-candidate={candidate}
    onFocusCapture={() => event('focus', candidate)}
    onCompositionStartCapture={() => event('composition-start', candidate)}
    onCompositionEndCapture={value => event('composition-end', candidate, value.data)}
    style={{ minWidth: 0, padding: 12, border: '1px solid var(--ov-border-default)' }}>
    {candidate === 'lightweight' ? <QueryInput {...common} rows={3} /> : <CelQueryEditor {...common}
      check={adapter.check} hover={adapter.hover} signature={adapter.signature}
      onDocumentClose={uri => { void adapter.closeDocument(uri).then(() => event('document-closed', candidate, uri)); }}
      onMount={(editor, monaco) => {
        evidence.monaco = monaco;
        evidence.editors[candidate] = editor;
        event('mounted', candidate, { elapsed: performance.now() - started, uri: editor.getModel()?.uri.toString() });
      }} />}
    <button data-after={candidate}>After {candidate} editor</button>
    <output data-document={candidate}>{JSON.stringify(document.text)}</output>
    <output data-submissions={candidate}>{submissions}</output>
  </div>;
}

export default function EditorFeasibility() {
  const [mounted, setMounted] = useState<Partial<Record<Candidate, number>>>({});
  const [overlay, setOverlay] = useState(false);
  const candidates: Candidate[] = ['lightweight', 'monaco'];
  const comparison = <div data-testid="p18-comparison" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, width: 'min(1100px, 83vw)' }}>
    {candidates.map(candidate => <section key={candidate} aria-label={`${candidate} comparison`}>
      <h2>{candidate}</h2>
      <button data-toggle={candidate} onClick={() => {
        event(mounted[candidate] === undefined ? 'mount-request' : 'unmount-request', candidate);
        setMounted(previous => ({ ...previous, [candidate]: previous[candidate] === undefined ? performance.now() : undefined }));
      }}>{mounted[candidate] === undefined ? 'Mount' : 'Dispose'} {candidate}</button>
      {mounted[candidate] !== undefined ? <CandidateSurface candidate={candidate} started={mounted[candidate]} /> : null}
    </section>)}
  </div>;
  return <main style={{ padding: 20, overflow: 'auto', height: '100%' }}>
    <h1>P18 real host editor comparison</h1>
    <p>Disposable source p18-host-comparison-37c896d0-v1. Existing UI69 surfaces; actual loopback CEL development LSP, cloud fixture profile only. Not a production host authoring service.</p>
    <Popover.Root open={overlay} onOpenChange={setOverlay}>
      <Popover.Trigger>Compare inside host popover</Popover.Trigger>
      <Popover.Portal><Popover.Positioner sideOffset={8}><Popover.Popup>
        <Popover.Title>P18 host overlay comparison</Popover.Title>
        {overlay ? comparison : null}
      </Popover.Popup></Popover.Positioner></Popover.Portal>
    </Popover.Root>
    {!overlay ? comparison : null}
  </main>;
}
