// Reproduce inside the browser Eval device with an opened owned host tab named p18tab.
// Main-world globals deliberately use tab.evaluate; raw page.evaluate is utility-world here.
var p18measure = async function(stage) {
  const base = await p18tab.run(async ({ page }) => {
    const cdp = await page.createCDPSession();
    await cdp.send("HeapProfiler.collectGarbage");
    const heap = await cdp.send("Runtime.getHeapUsage");
    const dom = await cdp.send("Memory.getDOMCounters");
    const targets = await cdp.send("Target.getTargets");
    await cdp.detach();
    return { heap, dom, workerTargets: targets.targetInfos.filter((t) => t.type.includes("worker")).map(({ type, url }) => ({ type, url })) };
  });
  const state = await p18tab.evaluate(`({source:window.__P18?.source,identity:window.__OMNIVIEW_BOOTSTRAP__?.identity,models:window.__P18?.monaco?.editor.getModels().map(m=>({uri:m.uri.toString(),disposed:m.isDisposed()}))??[],workers:window.__P18_WORKERS__,resources:performance.getEntriesByType('resource').map(r=>({name:r.name,initiatorType:r.initiatorType,transferSize:r.transferSize,encodedBodySize:r.encodedBodySize,decodedBodySize:r.decodedBodySize,duration:r.duration,startTime:r.startTime})),timeOrigin:performance.timeOrigin})`);
  return { stage, ...base, ...state };
};
var p18cycle = async function(candidate,count){return await p18tab.run(async({page},candidate,count)=>{const results=[];const methods=[];page.on('request',r=>{if(r.url().includes(':16138/lsp')){try{const b=JSON.parse(r.postData()||'{}');if(Array.isArray(b))methods.push(...b.map(v=>v.method).filter(Boolean));else if(b.method)methods.push(b.method);}catch{}}});for(let i=0;i<count;i++){const selector=`[data-candidate="${candidate}"] textarea[aria-label="${candidate} cloud query"]`;const start=await page.evaluate(()=>performance.now());await page.click(`[data-toggle="${candidate}"]`);await page.waitForSelector(selector,{visible:true});const ready=await page.evaluate(()=>performance.now());const focusStart=await page.evaluate(()=>performance.now());await page.focus(selector);const focusEnd=await page.evaluate(()=>performance.now());await page.keyboard.down('Control');await page.keyboard.press('Space');await page.keyboard.up('Control');await page.waitForSelector(candidate==='monaco'?'.suggest-widget.visible .monaco-list-row':'[role="listbox"][aria-label="Query suggestions"] [role="option"]',{visible:true});await page.keyboard.press('Escape');await page.click(`[data-toggle="${candidate}"]`);await page.waitForSelector(selector,{hidden:true});results.push({candidate,iteration:i,mountToVisibleMs:ready-start,focusMs:focusEnd-focusStart});}return {results,methods};},{args:[candidate,count],timeout:180});};
